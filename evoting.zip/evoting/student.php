<?php 
//include "admin_auth.php";
session_start();
$dbConnect=mysqli_connect('localhost', 'root', '');
  //$dbConnect=mysqli_connect('localhost', 'root', '');
  if (!$dbConnect)
  {
    $_SESSION['error']="Connection to Db fail ";
    header("Location: $domainName"."error/");
    exit();
  }
 // if (!mysqli_select_db($dbConnect, 'gradedin_cool'))
  if (!mysqli_select_db($dbConnect, 'voting'))
  {
    $_SESSION['error']="Connection to Library Db fail ";
    //echo "DB Selection failed Successful";
    header("Location: $domainName"."error/");
    exit();
  }
$name= $_SESSION['SESS_NAME'] ;
$sql= "SELECT * FROM student WHERE username = '$name' ";
      $result = mysqli_query($dbConnect,  $sql);
      while ($row = mysqli_fetch_array($result))
          {
            
            if ($row['status'] == 'VOTED')
            {
                header("Location: can_view2.php");
            }
          }
        if (!$result)
      {
        echo " failed to get result ooo";
      }
  

    

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>E-Voting</title>
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                   E-voting
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="student.php">
                        <i class="pe-7s-graph"></i>
                        <p>Home</p>
                    </a>
                </li>
                <li>
                    <a href="can_view.php">
                        <i class="pe-7s-user"></i>
                        <p>Candidate</p>
                    </a>
                </li>
               <!-- <li>
                    <a href="question.php">
                        <i class="pe-7s-note2"></i>
                        <p>Questions</p>
                    </a>
                </li>-->
                <li>
                    <a href="logout.php">
                        <i class="pe-7s-news-paper"></i>
                        <p>Logout</p>
                    </a>
                </li>
                
				<li class="active-pro">
                    <a href="">
                        <i class="pe-7s-rocket"></i>
                        <p>E-voting System</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
								<p class="hidden-lg hidden-md">Make a Vote</p>
                            </a>
                        </li>
                       <!-- <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-sm hidden-xs"></b>
                                    <span class="notification hidden-sm hidden-xs">5</span>
									<p class="hidden-lg hidden-md">
										5 Notifications
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>-->
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
								<p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               <p>Hello,&nbsp;<?php echo $_SESSION['SESS_NAME'] ;?></p>
                            </a>
                        </li>
                      <!--  <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Dropdown
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li>-->
                        <li>
                            <a href="#">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>







        <div class="content">
            <div class="container-fluid">
                <div class="row">
                <table width="100%">
<form action="student_vote.php" name="vote" method="post" id="myform">
<tr>
<td align="left"><img src="candidates/cand1.jpg" width="200px" height="100%"></td>
<td align="left">
<input type="radio" name="cand1" value="1" size="10"/>JOHN MICHAEL KALEMBE - President<br/><br/>
<input type="radio" name="vice1" value="3" size="10"/>JULIUS SAMWEL-Vice<br/>
</td>
<td align="left"><img src="candidates/cand2.jpg" width="200px" height="100%"></td>
</tr>
<tr>
<td align="left">&nbsp;</td>
<td align="left"><?php global $msg; echo $msg;?>
                <?php global $error; echo $error;?>
</td>
</tr>
<tr>
<td align="left"><img src="candidates/cand3.jpg" width="200px" height="100%"></td>
<td align="left">
<input type="radio" name="cand1" value="2" size="10"/>SUZAN JOHN - President<br/><br/>
<input type="radio" name="vice1" value="4" size="10"/>MICHAEL SANGA-Vice<br/>
</td>
<td align="left"><img src="candidates/cand4.jpg" width="200px" height="100%"></td>
</tr>
<tr>
<td align="center"><input type="submit" value="MAKE A VOTE" name="submit"/></td>
</tr>
</form>
<script type="text/javascript">
 var frmvalidator = new Validator("myform"); 
 frmvalidator.addValidation("cand1","req","Please select president candidate to vote for.");
 frmvalidator.addValidation("vice1","req","Please select vice candidate to vote for.");  
</script>

               
                </div>




             
                </div>
            </div>
        </div>



    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to E-Voting System Designed by Olagoke Damilola"

            },{
                type: 'info',
                timer: 6000
            });

    	});
	</script>

</html>
