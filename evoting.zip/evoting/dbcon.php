<?php
  session_start();
  require_once "siteconfig.php"; 
  
 $dbConnect=mysqli_connect('localhost', 'root', '');
  //$dbConnect=mysqli_connect('localhost', 'root', '');
  if (!$dbConnect)
  {
  	$_SESSION['error']="Connection to Db fail ";
	header("Location: $domainName"."error/");
	exit();
  }
 // if (!mysqli_select_db($dbConnect, 'gradedin_cool'))
  if (!mysqli_select_db($dbConnect, 'sportlite'))
  {
    $_SESSION['error']="Connection to Library Db fail ";
    //echo "DB Selection failed Successful";
	header("Location: $domainName"."error/");
	exit();
  }
require_once 'functions.php';?>