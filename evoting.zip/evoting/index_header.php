
     <?php include'connection.php'; ?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>E-voting</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <style>
    .logo{
      width:200px;
      height: 70px;
    }
    </style>
  </head>

  <body>

  <header>
    <div class="container">
    <td><h1>E-voting System</h1></td>
        <td><marquee>E-voting system designed by Olagoke</marquee></td>
      <?php 
      

      if(isset($_SESSION['logged']))
  {
     $a="";
        echo '
      <form action="login.php" autocomplete="on" class="form-inline" method="post">
        <div class="form-group">
          <label class="sr-only" for="exampleInputEmail3">Email address</label>
          <input type="email" class="form-control" id="exampleInputEmail3" name="email" required="required" placeholder="email">
        </div>
        <div class="form-group">
          <label class="sr-only" for="exampleInputPassword3">Password</label>
          <input type="password" class="form-control" id="exampleInputPassword3" name="password" required="required" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-default">Sign in</button><br>
        <div class="checkbox">
          <label>
            <input type="checkbox"> Remember me or <a href="signup.php" >Sign Up</a>
          </label>
        </div>
      </form>';
    }
    else{
      echo "";

    
 $a="    <li><a href=\"user/user.php\">My Profile</a></li>

  <li><a href=\"user/logout.php\">Logout</a></li>";

    } ?>
    </div>
  </header>
  