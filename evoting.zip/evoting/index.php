
<?php include('index_header.php'); ?>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
            <li ><a href="index.php">Home</a></li>
            <li ><a href="student_reg.php">Register</a></li>
            <li ><a href="login.php">Manual Login</a></li>
            <?php //echo $a;?>
            
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<?php
/*$id=$_GET['ui'];

$sql="SELECT *
    FROM user
    WHERE
    id='$id' ";
     $result = mysqli_query($dbConnect, $sql);
    if (!$result)
    {
      $_SESSION['error']="All user selection from submit: ". mysqli_error($dbConnect);
        header("Location: $domainName"."error/");
    exit();
    }
    while ($row = mysqli_fetch_array($result))
     {
    
    
    $name=$row['name'];
    $email=$row['email'];
    $State=$row['state'];
      $gender=$row['sex'];
    $Favourite=$row['sport'];
    $team=$row['team'];
    $passport=$row['passport'];
    $info=$row['info'];
    
   
    }*/
    
?>

    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="profile">
              <h1 class="page-header"><?php// echo $name;?></h1>
              <div class="row">
                <div class="col-md-4">
                	 <div class="col-md-6">
            <div class="text-center">
        <div id="camera_info"></div>
    <div id="camera"  ></div><br>
     
        </div>
                  
                </div>
                <div class="col-md-8">
               <ul>
                     <!--  <li><strong>Name: </strong><?php echo $name;?></li>
                    <li><strong>Email: </strong><?php echo $email;?></li>
                    <li><strong>Favourite Sport: </strong><?php echo $Favourite;?></li>
                    <li><strong>State: </strong><?php echo $State;?></li>
                    <li><strong>Gender: </strong><?php echo $gender;?></li>
                    <li><strong>Team: </strong><?php echo $team ;?></li>
                    <li><strong>About Me: </strong>"<?php echo $info;?>"</li>-->

                    <br><br>
                    <button id="take_snapshots" class="btn btn-primary" >Take Picture</button>
      </div>&nbsp;&nbsp;
                  </ul>
                </div>
              </div><br><br>
              <div class="row">
              <div class="col-md-6">
            <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th><th>Image Name</th><th><div>
                    <a class="btn btn-primary" href="#">Login</a>
                </div></th>

                </tr>
            </thead>
            <tbody id="imagelist">
            
            </tbody>
        </table>
        </div>
              </div>
            </div>
          </div>
          <?php  //include('sidebar.php') ?>
        </div>
      </div>
    </section>

    <footer>
      <div class="container">
        <p>E-voting Olagoke &copy 2019</p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
   <style>
#camera {
  width: 300px;
  height: 300px;
}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="jpeg_camera/jpeg_camera_with_dependencies.min.js" type="text/javascript"></script>
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<script>
    var options = {
      shutter_ogg_url: "jpeg_camera/shutter.ogg",
      shutter_mp3_url: "jpeg_camera/shutter.mp3",
      swf_url: "jpeg_camera/jpeg_camera.swf",
    };
    var camera = new JpegCamera("#camera", options);
  
  $('#take_snapshots').click(function(){
    var snapshot = camera.capture();
    snapshot.show();    
    
    snapshot.upload({api_url: "action.php"}).done(function(response) {
$('#imagelist').prepend("<tr><td><img src='"+response+"' width='100px' height='100px'></td><td>"+response+"</td><td><a href='recognise.php?img="+response+"'>Login This Image</a></td></tr>");
var pics = response;


//testing kairos
/*
var headers = {
  "Content-type"     : "application/json",
  "app_id"          : "a3dc66cc",
  "app_key"         : "ffe69759cf73a182262744ee155459f4"
};
var payload  = { "image" : response, "subject_id" : "Emma",
    "gallery_name" : "project" };
var url = "http://api.kairos.com/enroll";
// make request 
$.ajax(url, {
  headers  : headers,
    type: "POST",
    data: JSON.stringify(payload),
    dataType: "json"
}).then(function successCallback(response) {
      console.log(response);
      }, function errorCallback(response) {
      console.log(response);
      });
*/
//Testing end kiaros
//console.log(pics);
}).fail(function(response) {
     
  alert("Upload failed with status " + response);
  
});
})

function done(){
    $('#snapshots').html("uploaded");
}
</script>
<script> </script>
  </body>
</html>
