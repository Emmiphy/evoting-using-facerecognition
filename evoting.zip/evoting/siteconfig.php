<?php
  //$domainName="http://localhost/olsver1/";
  //$fileInclude = $_SERVER['DOCUMENT_ROOT'] . 'olsver1/';
  $sitename="Online Library System Version 1.2";
 // $domainName="http://gradedinfo.com/";
  $domainName="http://localhost/sportlite/";
    $fileInclude = $_SERVER['DOCUMENT_ROOT'] . 'sportlite/';
//  $fileInclude = $_SERVER['DOCUMENT_ROOT']."/";
  
  
  
  