<?php include "header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome, contact page.</h3><br/>
<p>You may find us with below conact:
<ul>
<li>website: <a href='index.php'>www.futoonline.com</a></li>

</ul>
</p>
<p>&nbsp;&nbsp;</p>
</div>
</div>
<?php include "footer.php";?>
