    
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"></head>
    <?php
// set variables
    $img = $_GET['img'];
$path = $img;
$type = pathinfo($path, PATHINFO_EXTENSION);
$data = file_get_contents($path);
$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
//echo $base64;
//echo '<img src="', $base64, '">';

    $queryUrl = "https://api.kairos.com/recognize";
//$queryUrl = "localhost/enroll/formProcessor2.php";

$APP_ID = "a3dc66cc";
$APP_KEY = "ffe69759cf73a182262744ee155459f4";
$request = curl_init($queryUrl);
$data = array(
    'image'=> $base64,
    
    'gallery_name' => 'project'
);
$payload = json_encode($data);
//echo $payload;
// set curl options
curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($request, CURLOPT_POST, true);
curl_setopt($request,CURLOPT_POSTFIELDS, $payload);
curl_setopt($request, CURLOPT_HTTPHEADER, array(
        
        "Content-type: application/json",
        'Content-Length: ' . strlen($payload),
        "app_id:" . $APP_ID,
        "app_key:" . $APP_KEY
    )
);
curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($request);
// show the API response
//echo $response;
// close the session
curl_close($request);
echo $response;

$yummya = json_decode($response, true);

 $a= $yummya['images'][0]['transaction']['subject_id'];
echo $a;
if ($a=='Serah'){
  echo "Welcome Ogechi, just a few step to complete this great App";
  header('location:login_action2.php?username=Ogechi&password=emma');
}
elseif($a=='Paul'){
   header('location:login_action2.php?username=Paul&password=emma');
     
}
elseif($a=='Emma')
{
    echo "Welcome Boss!";
}
else{
    echo "You are not Registered, please Register or Check your internet connection (Maximum page loading is 30 seconds).";
}

//$marks = array("Peter"=>65, "Harry"=>80, "John"=>78, "Clark"=>900);
//	echo "$firstName $lastName";

	//echo json_encode($marks);
?>

</html>