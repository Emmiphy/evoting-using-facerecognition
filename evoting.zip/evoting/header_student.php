<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="voting.css" type="text/css" rel="stylesheet" />
<title>Home</title>
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
</head>

<body>
<div id="head">
<table border="0" bgcolor="#FFFFFF"width="100%"><tr>
        <td><img src="logo.png" height="100" width="590" alt="logo"/></td>
        <td><marquee>evoting</marquee></td>
      </td>
</tr></table>
</div>
<div id="leftnavigation">
<a href="student.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="can_view.php">Candidate</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="question.php">Questions</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="logout.php">Logout</a>
&nbsp;&nbsp;|&nbsp;&nbsp;<a href="change_pass.php">Change Password</a>
</div>
