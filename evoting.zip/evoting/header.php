<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="voting.css" type="text/css" rel="stylesheet" />
<title>Home</title>
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
</head>

<body>
<div id="head">
<table border="0" bgcolor="#FFFFFF"width="100%"><tr>
        <td><h1>E-voting System</h1></td>
        <td><marquee>Futo voting system designed by Ogechi</marquee></td>
      </td>
</tr></table>
</div>
<div id="leftnavigation">
<a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="student_reg.php">Register</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="login.php">Login</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="about.php">About Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="contact.php">Contact Us</a>
</div>
